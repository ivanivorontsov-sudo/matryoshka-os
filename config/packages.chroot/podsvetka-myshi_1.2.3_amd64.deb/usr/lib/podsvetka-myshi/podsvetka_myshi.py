#!/usr/bin/python3
# Подсветка мыши — Linux/X11.
# Copyright (c) 2026 Ivan Vorontsov. MIT license.
import argparse
import fcntl
import inspect
import json
import logging
import math
import os
import re
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

# On KDE Wayland, render the transparent overlay through XWayland while KWin
# supplies the real global cursor coordinates over the session D-Bus.
WAYLAND_SESSION = os.environ.get("XDG_SESSION_TYPE", "").lower() == "wayland"
if WAYLAND_SESSION:
    os.environ["GDK_BACKEND"] = "x11"

import cairo
import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, GLib, Gtk
from Xlib import X, display as xdisplay

APP = "podsvetka-myshi"
KWIN_CLICK_EFFECT = "podsvetka-click"
VERSION = "1.2.3"
ANIMATION_STYLES = {
    "single": ("Одиночный импульс — без паутины", 1),
    "ripple": ("Двойная рябь", 2),
    "waves": ("Многослойная рябь", 4),
}
DEFAULTS = {
    "enabled": True, "only_moving": False, "glow_color": "#ffd54f",
    "glow_size": 110, "glow_alpha": 35, "click_effect": True,
    "left_color": "#ff5252", "right_color": "#448aff",
    "ring_radius": 18, "ring_alpha": 85, "ring_duration": 420, "ring_width": 2,
    "animation_style": "single",
}
RUNTIME = Path(os.environ.get("XDG_RUNTIME_DIR") or (Path.home() / ".cache" / APP))
CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / APP
STATE = Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state")) / APP
SOCKET = RUNTIME / "control.sock"
LOCK = RUNTIME / "instance.lock"


def log(message, exc=None):
    try:
        STATE.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(filename=str(STATE / "app.log"), level=logging.INFO,
                            format="%(asctime)s %(levelname)s %(message)s")
        logging.exception("%s: %s", message, exc) if exc else logging.info("%s", message)
    except Exception:
        pass


def clamp(value, low, high, default):
    try:
        return max(low, min(high, int(value)))
    except (TypeError, ValueError):
        return default


def color_ok(value, default):
    if isinstance(value, str) and len(value) == 7 and value[0] == "#":
        try:
            int(value[1:], 16)
            return value.lower()
        except ValueError:
            pass
    return default


def rgb(value):
    value = color_ok(value, "#ffffff")
    return tuple(int(value[i:i + 2], 16) / 255.0 for i in (1, 3, 5))


def parse_kwin_mouseclick_state(report):
    """Return MouseClickEffect.enabled from KWin's textual property dump."""
    match = re.search(
        r"(?im)^\s*enabled\s*:\s*(true|false|1|0|yes|no|on|off)\s*$",
        str(report),
    )
    if not match:
        return None
    return match.group(1).lower() in ("true", "1", "yes", "on")


def load_settings():
    data = dict(DEFAULTS)
    path = CONFIG / "settings.json"
    loaded = {}
    if path.exists():
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception as exc:
            log("Ошибка чтения настроек", exc)
            try:
                path.replace(path.with_suffix(".json.broken"))
            except Exception:
                pass
    # Migrate only the previous app defaults; do not overwrite user choices.
    schema = clamp(loaded.get("schema_version", 1), 1, 99, 1) if isinstance(loaded, dict) else 1
    if schema < 2:
        if loaded.get("ring_radius") == 100:
            data["ring_radius"] = 30
        if loaded.get("glow_size") == 150:
            data["glow_size"] = 110
    if schema < 3 and loaded.get("ring_radius") == 30:
        # 1.1.0 makes the default click ring less oversized on high-DPI screens.
        data["ring_radius"] = 18
    data["schema_version"] = 4
    if data.get("animation_style") not in ANIMATION_STYLES:
        data["animation_style"] = "single"
    current_session = os.environ.get("XDG_SESSION_ID") or os.environ.get("WAYLAND_DISPLAY", "")
    if data.get("_kwin_click_session", "") != current_session:
        data["_kwin_click_effect_enabled"] = False
    data["_kwin_click_session"] = current_session
    data["_kwin_click_effect_enabled"] = bool(data.get("_kwin_click_effect_enabled", False))
    for key in ("enabled", "only_moving", "click_effect"):
        data[key] = bool(data.get(key, DEFAULTS[key]))
    for key in ("glow_color", "left_color", "right_color"):
        data[key] = color_ok(data.get(key), DEFAULTS[key])
    for key, lo, hi in (("glow_size", 20, 400), ("glow_alpha", 5, 100),
                        ("ring_radius", 10, 300), ("ring_alpha", 5, 100),
                        ("ring_duration", 150, 3000), ("ring_width", 1, 12)):
        data[key] = clamp(data.get(key), lo, hi, DEFAULTS[key])
    data["autostart"] = bool(data.get("autostart", False))
    return data


def save_settings(data):
    CONFIG.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix="settings-", suffix=".tmp", dir=str(CONFIG))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(name, CONFIG / "settings.json")
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass


def set_autostart(enabled):
    target = Path.home() / ".config" / "autostart" / (APP + ".desktop")
    if not enabled:
        try:
            target.unlink()
        except FileNotFoundError:
            pass
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    candidates = [
        Path("/usr/bin/podsvetka-myshi-launch"),
        Path.home() / ".local" / "bin" / "podsvetka-myshi-launch",
    ]
    launcher = next((candidate for candidate in candidates if candidate.is_file()), None)
    if launcher:
        executable = str(launcher).replace("\\", "\\\\").replace('"', '\\"')
        command = '"' + executable + '" --autostart'
    else:
        py = (sys.executable or "/usr/bin/python3").replace("\\", "\\\\").replace('"', '\\"')
        script = str(Path(__file__).resolve()).replace("\\", "\\\\").replace('"', '\\"')
        command = '"' + py + '" "' + script + '" --autostart'
    target.write_text(
        "[Desktop Entry]\nType=Application\nName=Подсветка мыши\n"
        "Comment=Подсветка курсора и анимация щелчков\n"
        "Exec=" + command + "\n"
        "Icon=input-mouse\nTerminal=false\nNoDisplay=true\n",
        encoding="utf-8",
    )


def send_command(command, retries=1):
    """
    Send a command to the active instance. A just-started GTK app may have
    created its overlay before its IPC thread binds the socket, so allow a
    short bounded retry window for menu actions and shutdown.
    """
    attempts = max(1, min(20, int(retries)))
    for attempt in range(attempts):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
                s.settimeout(0.4)
                s.connect(str(SOCKET))
                s.sendall(command.encode("ascii"))
            return True
        except OSError:
            if attempt + 1 < attempts:
                time.sleep(0.1)
    return False


def acquire_lock():
    RUNTIME.mkdir(parents=True, exist_ok=True)
    handle = open(LOCK, "a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return handle
    except BlockingIOError:
        handle.close()
        return None


def ease_out(t):
    t = max(0.0, min(1.0, float(t)))
    return 1.0 - (1.0 - t) ** 3


def draw_glow(ctx, x, y, size, color, alpha):
    r, g, b = rgb(color)
    radius = size / 2.0
    grad = cairo.RadialGradient(x, y, 0, x, y, radius)
    grad.add_color_stop_rgba(0, r, g, b, alpha / 100.0 * 0.42)
    grad.add_color_stop_rgba(0.5, r, g, b, alpha / 100.0 * 0.2)
    grad.add_color_stop_rgba(1, r, g, b, 0)
    ctx.set_source(grad)
    ctx.arc(x, y, radius, 0, math.pi * 2)
    ctx.fill()


class App:
    def __init__(self, open_settings=False):
        self.cfg = load_settings()
        self.rings = []
        self.position = None
        self.glow_pos = None
        self.glow_on = False
        self.last_move = time.monotonic()
        self.last_mask = 0
        self.running = True
        self.stop = threading.Event()
        self.server = None
        # Keep modal GTK dialogs visible to shutdown(); Gtk.Dialog.run() starts
        # a nested main loop which Gtk.main_quit() alone does not reliably close.
        self.active_dialogs = []
        self.wayland_mode = WAYLAND_SESSION
        self.dbus = None
        self.dbus_bus = None
        self.dbus_name = None
        self.kwin_receiver = None

        display = Gdk.Display.get_default()
        display_name = display.get_name() if display else ""
        if self.wayland_mode and not os.environ.get("DISPLAY"):
            raise RuntimeError(
                "Для подсветки в KDE Wayland нужен XWayland. "
                "Перезапустите сеанс Plasma с установленным пакетом xwayland."
            )
        if not self.wayland_mode and "wayland" in display_name.lower():
            raise RuntimeError(
                "GTK подключился напрямую к Wayland вместо XWayland. "
                "Проверьте наличие XWayland и переменную DISPLAY."
            )
        self.xdisplay = xdisplay.Display()
        self.root = self.xdisplay.screen().root
        visual = Gdk.Screen.get_default().get_rgba_visual()
        if visual is None:
            raise RuntimeError("Нет RGBA-визуала: для прозрачной подсветки нужен композитный менеджер окон.")

        self.window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        self.window.set_title("Подсветка мыши")
        self.window.set_decorated(False)
        self.window.set_app_paintable(True)
        self.window.set_visual(visual)
        self.window.set_accept_focus(False)
        self.window.set_focus_on_map(False)
        self.window.set_skip_taskbar_hint(True)
        self.window.set_skip_pager_hint(True)
        self.window.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.window.connect("draw", self.on_draw)
        self.resize_window()
        self.window.realize()
        gdk_window = self.window.get_window()
        if not self.wayland_mode:
            gdk_window.set_override_redirect(True)
        else:
            # A managed XWayland surface can be placed in KWin's above layer;
            # override-redirect would bypass KWin's stacking policy.
            self.window.set_keep_above(True)
        gdk_window.set_pass_through(True)
        self.window.input_shape_combine_region(cairo.Region())
        self.window.show_all()

        self.create_tray()
        self.start_ipc()
        if self.wayland_mode:
            self.start_kwin_bridge()
            try:
                self.configure_kwin_mouseclick(self.cfg["click_effect"], persist=True)
            except Exception as exc:
                log("Не удалось включить анимацию щелчков KWin", exc)
                self.message_error("Не удалось включить анимацию щелчков KWin: " + str(exc))
        GLib.timeout_add(8, self.tick)
        if open_settings:
            GLib.idle_add(self.settings_dialog)
        log("Linux/X11 version started")

    def resize_window(self):
        geo = self.root.get_geometry()
        self.window.set_default_size(int(geo.width), int(geo.height))
        self.window.move(0, 0)
        self.window.resize(int(geo.width), int(geo.height))

    def create_tray(self):
        try:
            self.tray = Gtk.StatusIcon.new_from_icon_name("input-mouse")
            self.tray.set_tooltip_text("Подсветка мыши")
            self.tray.set_visible(True)
            self.tray.connect("activate", lambda *_: self.settings_dialog())
            self.tray.connect("popup-menu", self.tray_menu)
        except Exception as exc:
            self.tray = None
            log("Значок системного лотка недоступен", exc)

    def tray_menu(self, icon, button, timestamp):
        menu = Gtk.Menu()

        # Put the animation selector directly in the tray context menu as well
        # as in the full settings dialog, so the choice is discoverable.
        styles_menu = Gtk.Menu()
        group = None
        for style_id, (style_label, _ring_count) in ANIMATION_STYLES.items():
            item = Gtk.RadioMenuItem.new_with_label(group, style_label)
            if group is None:
                group = item.get_group()
            item.set_active(self.cfg.get("animation_style", "single") == style_id)
            item.connect(
                "toggled",
                lambda widget, selected=style_id:
                    self.set_animation_style(selected) if widget.get_active() else None
            )
            styles_menu.append(item)
        styles_item = Gtk.MenuItem.new_with_label("Анимация щелчков")
        styles_item.set_submenu(styles_menu)
        menu.append(styles_item)
        menu.append(Gtk.SeparatorMenuItem())

        for label, callback in (
            ("Настройки…", lambda: self.settings_dialog()),
            ("Переключить подсветку", lambda: self.handle("toggle")),
            ("Выход", lambda: self.shutdown()),
        ):
            item = Gtk.MenuItem.new_with_label(label)
            item.connect("activate", lambda _item, cb=callback: cb())
            menu.append(item)
        menu.show_all()
        menu.popup(None, None, None, None, button, timestamp)

    def set_animation_style(self, style_id):
        """Apply a click animation preset from the tray menu immediately."""
        if style_id not in ANIMATION_STYLES:
            log("Неизвестный стиль анимации: " + str(style_id))
            return
        if self.cfg.get("animation_style", "single") == style_id:
            return
        self.cfg["animation_style"] = style_id
        try:
            save_settings(self.cfg)
            if self.wayland_mode and self.cfg.get("click_effect", True):
                self.configure_kwin_mouseclick(True, persist=True)
            self.rings.clear()
            self.window.queue_draw()
            log("Выбран стиль анимации щелчка: " + style_id)
        except Exception as exc:
            log("Не удалось применить стиль анимации щелчка", exc)
            self.message_error("Не удалось применить стиль анимации: " + str(exc))

    def start_ipc(self):
        try:
            try:
                SOCKET.unlink()
            except FileNotFoundError:
                pass
            self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.server.bind(str(SOCKET))
            os.chmod(SOCKET, 0o600)
            self.server.listen(4)
            self.server.settimeout(0.5)
            threading.Thread(target=self.ipc_loop, daemon=True, name="podsvetka-ipc").start()
            log("Управляющий сокет запущен: " + str(SOCKET))
        except Exception as exc:
            log("Не удалось открыть управляющий сокет", exc)
            raise RuntimeError("Не удалось открыть локальный управляющий сокет " + str(SOCKET) + ": " + str(exc)) from exc

    def start_kwin_bridge(self):
        """Bridge KWin's compositor-owned cursor coordinates into the XWayland overlay."""
        try:
            import dbus
            import dbus.service
            from dbus.mainloop.glib import DBusGMainLoop

            self.dbus = dbus
            DBusGMainLoop(set_as_default=True)
            self.dbus_bus = dbus.SessionBus()
            self.dbus_name = dbus.service.BusName(
                "org.podsvetka.Myshi", bus=self.dbus_bus, do_not_queue=True
            )
            app = self

            class CursorReceiver(dbus.service.Object):
                @dbus.service.method(
                    "org.podsvetka.Myshi", in_signature="ii", out_signature=""
                )
                def SetCursorPosition(self, x, y):
                    GLib.idle_add(app.receive_cursor_position, int(x), int(y))

            self.kwin_receiver = CursorReceiver(self.dbus_bus, "/org/podsvetka/Myshi")
            self.configure_kwin_script(True)
            log("Мост KDE/KWin Wayland запущен через D-Bus")
        except Exception as exc:
            log("Не удалось запустить мост KDE/KWin Wayland", exc)
            raise RuntimeError(
                "Не удалось включить поддержку KDE Wayland. Нужны KDE Plasma/KWin, "
                "XWayland и пакет python3-dbus. Подробности: "
                + str(STATE / "app.log")
            ) from exc

    def _write_kwin_entries(self, group, values):
        """Update only the requested KWin keys, preserving the rest of kwinrc."""
        kwriteconfig = shutil.which("kwriteconfig6") or shutil.which("kwriteconfig5")
        if kwriteconfig:
            for key, value in values.items():
                subprocess.run(
                    [kwriteconfig, "--file", "kwinrc", "--group", group,
                     "--key", key, str(value)],
                    check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                )
            return

        config = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "kwinrc"
        lines = config.read_text(encoding="utf-8").splitlines() if config.exists() else []
        header = "[" + group + "]"
        section_start = next(
            (i for i, line in enumerate(lines) if line.strip().lower() == header.lower()),
            None,
        )
        if section_start is None:
            if lines and lines[-1].strip():
                lines.append("")
            lines.append(header)
            section_start = len(lines) - 1
            section_end = len(lines)
        else:
            section_end = next(
                (i for i in range(section_start + 1, len(lines))
                 if lines[i].strip().startswith("[") and lines[i].strip().endswith("]")),
                len(lines),
            )
        for key, value in values.items():
            key_line = key + "=" + str(value)
            found = next(
                (i for i in range(section_start + 1, section_end)
                 if lines[i].split("=", 1)[0].strip().lower() == key.lower()),
                None,
            )
            if found is None:
                lines.insert(section_end, key_line)
                section_end += 1
            else:
                lines[found] = key_line
        config.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix="kwinrc-", dir=str(config.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                stream.write("\n".join(lines) + "\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, config)
        finally:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass

    def _kwin_interface(self):
        obj = self.dbus_bus.get_object("org.kde.KWin", "/KWin")
        return self.dbus.Interface(obj, "org.kde.KWin")

    def _kwin_effects_interface(self):
        obj = self.dbus_bus.get_object("org.kde.KWin", "/Effects")
        return self.dbus.Interface(obj, "org.kde.kwin.Effects")

    def _ensure_kwin_mouseclick_loaded(self):
        """Load the custom KWin effect that emits exactly one animation per press."""
        effects = self._kwin_effects_interface()

        # KWin's built-in mouseclick effect animates both press and release.
        # Disable it permanently for this app and use our press-only plugin.
        self._write_kwin_entries("Plugins", {
            "mouseclickEnabled": "false",
            KWIN_CLICK_EFFECT + "Enabled": "false",
        })
        if bool(effects.isEffectLoaded("mouseclick")):
            effects.unloadEffect("mouseclick")
            for _ in range(40):
                if not bool(effects.isEffectLoaded("mouseclick")):
                    break
                time.sleep(0.05)

        if not bool(effects.isEffectSupported(KWIN_CLICK_EFFECT)):
            raise RuntimeError(
                "KWin пока не обнаружил эффект «Подсветка мыши — одиночный щелчок». "
                "После установки версии 1.2.0 один раз выйдите из сеанса Plasma "
                "и войдите снова: KWin сканирует новые плагины при запуске."
            )

        if bool(effects.isEffectLoaded(KWIN_CLICK_EFFECT)):
            return

        # loadEffect() is idempotent only at the caller level; confirm state
        # rather than trusting its return value.
        effects.loadEffect(KWIN_CLICK_EFFECT)
        for _ in range(40):
            if bool(effects.isEffectLoaded(KWIN_CLICK_EFFECT)):
                log("Пользовательский KWin effect podsvetka-click загружен")
                return
            time.sleep(0.05)
        raise RuntimeError(
            "KWin не загрузил podsvetka-click. Подробности: "
            + str(STATE / "app.log")
        )

    def _kwin_mouseclick_state(self):
        """Read the loaded/enabled state of the custom press-only effect."""
        try:
            effects = self._kwin_effects_interface()
            if not bool(effects.isEffectLoaded(KWIN_CLICK_EFFECT)):
                return False
            report = str(effects.supportInformation(KWIN_CLICK_EFFECT))
            state = parse_kwin_mouseclick_state(report)
            if state is None:
                log(
                    "KWin не вернул свойство enabled для "
                    + KWIN_CLICK_EFFECT + ": " + repr(report)
                )
            return state
        except Exception as exc:
            log("Не удалось прочитать состояние пользовательского KWin effect", exc)
            return None

    def configure_kwin_mouseclick(self, enabled, persist=False):
        """
        Configure the custom KWin effect. Unlike the built-in MouseClickEffect,
        it reacts only to button-down events, so one physical click creates one
        animation rather than one on press plus another on release.
        """
        if not self.wayland_mode or self.dbus_bus is None:
            return

        enabled = bool(enabled)
        effects = self._kwin_effects_interface()

        # The native KWin effect creates separate animations on both button
        # transitions. Keep it disabled even when our own effect is turned off.
        self._write_kwin_entries("Plugins", {
            "mouseclickEnabled": "false",
            KWIN_CLICK_EFFECT + "Enabled": "false",
        })
        self._write_kwin_entries("Effect-" + KWIN_CLICK_EFFECT, {
            "Color1": self.cfg["left_color"],
            "Color2": "#ffffff",
            "Color3": self.cfg["right_color"],
            "LineWidth": self.cfg["ring_width"],
            "RingLife": self.cfg["ring_duration"],
            "RingSize": self.cfg["ring_radius"],
            "RingCount": ANIMATION_STYLES[self.cfg.get("animation_style", "single")][1],
        })
        self._kwin_interface().reconfigure()

        # Some distributions keep an already-loaded built-in effect alive
        # after kwinrc was changed. Explicitly unload it before proceeding.
        if bool(effects.isEffectLoaded("mouseclick")):
            effects.unloadEffect("mouseclick")
            for _ in range(40):
                if not bool(effects.isEffectLoaded("mouseclick")):
                    break
                time.sleep(0.05)

        if enabled:
            self._ensure_kwin_mouseclick_loaded()
            effects.reconfigureEffect(KWIN_CLICK_EFFECT)
            deadline = time.monotonic() + 2.0
            actual = None
            while time.monotonic() < deadline:
                actual = self._kwin_mouseclick_state()
                if actual is True:
                    break
                time.sleep(0.05)
            if actual is not True:
                raise RuntimeError(
                    "KWin загрузил пользовательский эффект, но не подтвердил его состояние. "
                    "Проверьте совместимость плагина с версией KWin 6.3.6."
                )
        else:
            if bool(effects.isEffectLoaded(KWIN_CLICK_EFFECT)):
                effects.unloadEffect(KWIN_CLICK_EFFECT)
            for _ in range(40):
                if not bool(effects.isEffectLoaded(KWIN_CLICK_EFFECT)):
                    break
                time.sleep(0.05)
            if bool(effects.isEffectLoaded(KWIN_CLICK_EFFECT)):
                raise RuntimeError("KWin не подтвердил выгрузку podsvetka-click.")

        self.cfg["_kwin_click_effect_enabled"] = enabled
        self.cfg["_kwin_click_session"] = (
            os.environ.get("XDG_SESSION_ID") or os.environ.get("WAYLAND_DISPLAY", "")
        )
        if persist:
            save_settings(self.cfg)
        log(
            "Одиночная анимация щелчков KWin: "
            + ("включена" if enabled else "выключена")
        )

    def configure_kwin_script(self, enabled):
        """Enable or disable the installed KWin package script by its plugin id."""
        data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
        target = data_home / "kwin" / "scripts" / APP
        source = Path("/usr/share/kwin/scripts") / APP
        if not source.is_dir():
            source = Path(__file__).resolve().parent / "kwin-script"
        if not source.is_dir() and target.is_dir():
            source = target
        if not (source / "metadata.json").is_file():
            raise RuntimeError("Не найден пакет KWin script: " + str(source))
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.resolve() != target.resolve():
            shutil.copytree(source, target, dirs_exist_ok=True)

        scripting_obj = self.dbus_bus.get_object("org.kde.KWin", "/Scripting")
        scripting = self.dbus.Interface(scripting_obj, "org.kde.kwin.Scripting")

        # KWin's D-Bus loadScript export accepts only the file path on supported
        # Plasma 6 builds. To retain the stable plugin id, register the script
        # as a normal KPackage and let KWin discover it from metadata.json.
        # The Plugins key is <KPlugin.Id>Enabled.
        self._write_kwin_entries("Plugins", {APP + "Enabled": "true" if enabled else "false"})
        self._kwin_interface().reconfigure()

        if enabled:
            # The config change normally starts the script loader itself;
            # start() is also called explicitly for installations where the
            # config watcher hasn't emitted yet. It is idempotent by plugin id.
            scripting.start()
            for _ in range(60):
                if bool(scripting.isScriptLoaded(APP)):
                    log("KWin cursor bridge загружен как пакет " + APP)
                    return
                time.sleep(0.05)
            raise RuntimeError(
                "KWin не загрузил скрипт " + APP + " из "
                + str(target / "metadata.json")
                + ". Проверьте журнал KWin и пакетный metadata.json."
            )

        if bool(scripting.isScriptLoaded(APP)):
            scripting.unloadScript(APP)
        for _ in range(40):
            if not bool(scripting.isScriptLoaded(APP)):
                log("KWin cursor bridge выгружен")
                return
            time.sleep(0.05)
        raise RuntimeError("KWin не подтвердил выгрузку скрипта " + APP + ".")

    def receive_cursor_position(self, x, y):
        now = time.monotonic()
        if self.position != (x, y):
            self.last_move = now
        self.position = (x, y)
        return False

    def ipc_loop(self):
        while not self.stop.is_set():
            try:
                conn, _ = self.server.accept()
            except socket.timeout:
                continue
            except (OSError, AttributeError):
                break
            try:
                cmd = conn.recv(64).decode("ascii", errors="ignore").strip()
                GLib.idle_add(self.handle, cmd)
            except Exception as exc:
                log("IPC error", exc)
            finally:
                conn.close()

    def handle(self, cmd):
        if cmd in ("settings", "show"):
            # Launching the menu entry a second time should reveal settings,
            # not silently do nothing while the background glow keeps running.
            self.settings_dialog()
        elif cmd == "activate":
            pass
        elif cmd == "quit":
            self.shutdown()
        elif cmd == "toggle":
            self.cfg["enabled"] = not self.cfg["enabled"]
            save_settings(self.cfg)
            self.window.queue_draw()
        return False

    def settings_dialog(self):
        cfg = dict(self.cfg)
        dlg = Gtk.Dialog(title="Настройки — Подсветка мыши", transient_for=None, flags=0)
        dlg.set_resizable(False)
        dlg.add_button("Отмена", Gtk.ResponseType.CANCEL)
        dlg.add_button("Сохранить", Gtk.ResponseType.OK)
        dlg.set_default_response(Gtk.ResponseType.OK)
        grid = Gtk.Grid(column_spacing=14, row_spacing=9, border_width=16)
        dlg.get_content_area().add(grid)

        def add(label, widget, y):
            grid.attach(Gtk.Label(label=label, xalign=0), 0, y, 1, 1)
            widget.set_hexpand(True)
            grid.attach(widget, 1, y, 1, 1)

        def scale(low, high, value):
            w = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, low, high, 1)
            w.set_digits(0)
            w.set_value(value)
            w.set_size_request(230, -1)
            return w

        def color(value):
            rgba = Gdk.RGBA()
            rgba.parse(value)
            w = Gtk.ColorButton.new_with_rgba(rgba)
            w.set_use_alpha(False)
            return w

        enabled = Gtk.CheckButton.new_with_label("Подсветка включена")
        enabled.set_active(cfg["enabled"])
        grid.attach(enabled, 0, 0, 2, 1)
        moving = Gtk.CheckButton.new_with_label("Показывать только при движении мыши")
        moving.set_active(cfg["only_moving"])
        grid.attach(moving, 0, 1, 2, 1)
        glow_size = scale(20, 400, cfg["glow_size"])
        glow_alpha = scale(5, 100, cfg["glow_alpha"])
        glow_color = color(cfg["glow_color"])
        add("Размер свечения (пикс.)", glow_size, 2)
        add("Непрозрачность свечения (%)", glow_alpha, 3)
        add("Цвет подсветки", glow_color, 4)
        clicks = Gtk.CheckButton.new_with_label("Анимировать щелчки мыши")
        # Explicitly keep this control interactive. Some KDE/GTK themes render
        # check buttons as insensitive when inherited state is stale.
        clicks.set_sensitive(True)
        clicks.set_active(cfg["click_effect"])
        if self.wayland_mode:
            clicks.set_tooltip_text(
                "Включает или выключает встроенную анимацию щелчков KWin. "
                "Изменение применяется после нажатия «Сохранить»."
            )
        grid.attach(clicks, 0, 5, 2, 1)
        left = color(cfg["left_color"])
        right = color(cfg["right_color"])
        ring_size = scale(8, 120, cfg["ring_radius"])
        ring_alpha = scale(5, 100, cfg["ring_alpha"])
        duration = scale(150, 3000, cfg["ring_duration"])
        width = scale(1, 12, cfg["ring_width"])
        animation_style = Gtk.ComboBoxText.new()
        for style_id, (style_label, _ring_count) in ANIMATION_STYLES.items():
            animation_style.append(style_id, style_label)
        animation_style.set_active_id(cfg.get("animation_style", "single"))
        animation_style.set_sensitive(clicks.get_active())
        animation_style.set_tooltip_text(
            "Одиночный импульс рисует одно кольцо. Двойная и многослойная рябь "
            "добавляют следующие волны с небольшой задержкой."
        )
        clicks.connect(
            "toggled",
            lambda widget: animation_style.set_sensitive(widget.get_active())
        )
        add("Стиль анимации щелчка", animation_style, 6)
        add("Цвет левого щелчка", left, 7)
        add("Цвет правого щелчка", right, 8)
        add("Размер круга — радиус (пикс.)", ring_size, 9)
        if not self.wayland_mode:
            add("Непрозрачность круга (%)", ring_alpha, 10)
        else:
            opacity_info = Gtk.Label(label="Автоматическое затухание KWin")
            opacity_info.set_xalign(0)
            opacity_info.set_tooltip_text(
                "Встроенный эффект KWin сам рассчитывает прозрачность каждого кадра. "
                "Он не предоставляет ручную настройку прозрачности."
            )
            add("Прозрачность круга", opacity_info, 10)
        add("Длительность (мс)", duration, 11)
        add("Толщина линии", width, 12)
        autostart = Gtk.CheckButton.new_with_label("Запускать при входе в систему")
        autostart.set_active(cfg["autostart"])
        grid.attach(autostart, 0, 13, 2, 1)
        dlg.show_all()

        self.active_dialogs.append(dlg)
        try:
            response = dlg.run()
        finally:
            if dlg in self.active_dialogs:
                self.active_dialogs.remove(dlg)

        if response == Gtk.ResponseType.OK:
            cfg.update({
                "enabled": enabled.get_active(),
                "only_moving": moving.get_active(),
                "click_effect": clicks.get_active(),
                "animation_style": animation_style.get_active_id() or "single",
                "glow_size": int(glow_size.get_value()),
                "glow_alpha": int(glow_alpha.get_value()),
                "glow_color": self.to_hex(glow_color.get_rgba()),
                "left_color": self.to_hex(left.get_rgba()),
                "right_color": self.to_hex(right.get_rgba()),
                "ring_radius": int(ring_size.get_value()),
                "ring_alpha": int(ring_alpha.get_value()),
                "ring_duration": int(duration.get_value()),
                "ring_width": int(width.get_value()),
                "autostart": autostart.get_active(),
            })
            try:
                save_settings(cfg)
                set_autostart(cfg["autostart"])
                self.cfg = cfg
                if self.wayland_mode:
                    try:
                        self.configure_kwin_mouseclick(cfg["click_effect"], persist=True)
                    except Exception as exc:
                        log("Ошибка применения настроек анимации KWin", exc)
                        self.message_error(
                            "Настройки сохранены, но KWin не применил анимацию щелчков: " + str(exc)
                        )
                self.rings.clear()
                self.last_move = time.monotonic()
                self.glow_pos = None
                self.glow_on = False
                self.window.queue_draw()
            except Exception as exc:
                log("Ошибка сохранения настроек", exc)
                self.message_error("Не удалось сохранить настройки: " + str(exc))
        dlg.destroy()
        return False

    @staticmethod
    def to_hex(value):
        return "#{:02x}{:02x}{:02x}".format(round(value.red * 255),
                                             round(value.green * 255),
                                             round(value.blue * 255))

    def message_error(self, message):
        dlg = Gtk.MessageDialog(transient_for=None, flags=Gtk.DialogFlags.MODAL,
                                message_type=Gtk.MessageType.ERROR,
                                buttons=Gtk.ButtonsType.OK, text="Подсветка мыши")
        dlg.format_secondary_text(message)
        self.active_dialogs.append(dlg)
        try:
            dlg.run()
        finally:
            if dlg in self.active_dialogs:
                self.active_dialogs.remove(dlg)
            dlg.destroy()

    def invalidate(self, x, y, radius):
        m = int(radius + self.cfg["ring_width"] + 5)
        self.window.queue_draw_area(int(x - m), int(y - m), 2 * m + 1, 2 * m + 1)

    def on_draw(self, widget, ctx):
        ctx.set_operator(cairo.OPERATOR_CLEAR)
        ctx.paint()
        ctx.set_operator(cairo.OPERATOR_OVER)
        if self.glow_on and self.glow_pos:
            draw_glow(ctx, self.glow_pos[0], self.glow_pos[1],
                      self.cfg["glow_size"], self.cfg["glow_color"], self.cfg["glow_alpha"])
        now = time.monotonic()
        for ring in self.rings:
            elapsed_ms = max(0.0, (now - ring["start"]) * 1000.0)
            duration_ms = max(1.0, float(ring["duration"]))
            count = max(1, int(ring.get("count", 1)))
            r, g, b = rgb(ring["color"])
            furthest_radius = ring.get("drawn", 0)
            for index in range(count):
                # Stagger each wave, like KWin's native Mouse Click Animation.
                delay_ms = duration_ms * index / (count * 3.0)
                t = (elapsed_ms - delay_ms) / duration_ms
                if t < 0.0 or t > 1.0:
                    continue
                radius = ring["radius"] * (0.12 + ease_out(t) * 0.88)
                alpha = (1.0 - t) * ring.get("alpha", 95) / 100.0
                ctx.set_source_rgba(r, g, b, alpha)
                ctx.set_line_width(ring["width"])
                ctx.arc(ring["x"], ring["y"], radius, 0, math.pi * 2)
                ctx.stroke()
                furthest_radius = max(furthest_radius, radius)
            ring["drawn"] = furthest_radius
        return False

    def add_ring(self, x, y, color, now):
        self.rings.append({
            "x": x, "y": y, "color": color, "start": now,
            "duration": self.cfg["ring_duration"], "radius": self.cfg["ring_radius"],
            "alpha": self.cfg["ring_alpha"], "width": self.cfg["ring_width"],
            "count": ANIMATION_STYLES[self.cfg.get("animation_style", "single")][1],
            "drawn": 0,
        })

    def tick(self):
        if not self.running:
            return False
        now = time.monotonic()
        if self.wayland_mode:
            if self.position is None:
                return True
            x, y = self.position
            mask = 0  # KWin's supported scripting API exposes position, not button state.
        else:
            try:
                pointer = self.root.query_pointer()
                x, y, mask = int(pointer.root_x), int(pointer.root_y), int(pointer.mask)
            except Exception as exc:
                log("Не удалось получить позицию указателя", exc)
                return True

        if self.position != (x, y):
            self.last_move = now
        show = self.cfg["enabled"] and (not self.cfg["only_moving"] or now - self.last_move < 0.8)
        if self.glow_on and self.glow_pos:
            self.invalidate(*self.glow_pos, self.cfg["glow_size"] / 2)
        if show:
            self.invalidate(x, y, self.cfg["glow_size"] / 2)
            self.glow_pos = (x, y)
        else:
            self.glow_pos = None
        self.glow_on = show

        if self.cfg["enabled"] and self.cfg["click_effect"]:
            if (mask & X.Button1Mask) and not (self.last_mask & X.Button1Mask):
                self.add_ring(x, y, self.cfg["left_color"], now)
            if (mask & X.Button3Mask) and not (self.last_mask & X.Button3Mask):
                self.add_ring(x, y, self.cfg["right_color"], now)
            self.last_mask = mask

        alive = []
        for ring in self.rings:
            elapsed = (now - ring["start"]) * 1000
            t = max(0.0, min(1.0, elapsed / ring["duration"]))
            radius = ring["radius"] * (0.12 + ease_out(t) * 0.88)
            self.invalidate(ring["x"], ring["y"], max(radius, ring["drawn"]) + ring["width"] + 4)
            ring["drawn"] = radius
            if elapsed < ring["duration"]:
                alive.append(ring)
        self.rings = alive
        self.position = (x, y)
        return True

    def shutdown(self):
        if not self.running:
            return False

        # A modal dialog runs its own nested GTK loop. Send a response to every
        # open dialog (innermost first) so --quit can unwind those loops and
        # release the single-instance flock instead of leaving a ghost process.
        for dialog in reversed(list(self.active_dialogs)):
            try:
                dialog.response(Gtk.ResponseType.CANCEL)
            except Exception as exc:
                log("Не удалось закрыть модальное окно при выходе", exc)

        self.running = False
        self.stop.set()
        try:
            self.server.close()
        except Exception:
            pass
        try:
            SOCKET.unlink()
        except FileNotFoundError:
            pass
        if self.wayland_mode and self.dbus_bus is not None:
            try:
                self.configure_kwin_mouseclick(False, persist=True)
            except Exception as exc:
                log("Не удалось выключить анимацию KWin при выходе", exc)
            try:
                self.configure_kwin_script(False)
            except Exception as exc:
                log("Не удалось выключить KWin script при выходе", exc)
            try:
                if self.kwin_receiver is not None:
                    self.kwin_receiver.remove_from_connection()
            except Exception:
                pass
            self.kwin_receiver = None
            self.dbus_name = None
            self.dbus_bus = None
        try:
            if self.tray:
                self.tray.set_visible(False)
        except Exception:
            pass
        self.xdisplay.close()
        self.window.destroy()
        Gtk.main_quit()
        return False


def set_autostart(enabled):
    target = Path.home() / ".config" / "autostart" / (APP + ".desktop")
    if not enabled:
        try:
            target.unlink()
        except FileNotFoundError:
            pass
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    py = (sys.executable or "/usr/bin/python3").replace("\\", "\\\\").replace('"', '\\"')
    script = str(Path(__file__).resolve()).replace("\\", "\\\\").replace('"', '\\"')
    target.write_text(
        "[Desktop Entry]\nType=Application\nName=Подсветка мыши\n"
        "Comment=Подсветка курсора и анимация щелчков\n"
        'Exec="' + py + '" "' + script + '" --autostart\n'
        "Icon=input-mouse\nTerminal=false\nNoDisplay=true\n",
        encoding="utf-8",
    )


def self_test():
    assert parse_kwin_mouseclick_state("mouseclick:\nenabled: true\n") is True
    assert parse_kwin_mouseclick_state("mouseclick:\nenabled: false\n") is False
    assert parse_kwin_mouseclick_state("mouseclick:\nenabled: 1\n") is True
    assert parse_kwin_mouseclick_state("mouseclick:\nenabled: 0\n") is False
    assert parse_kwin_mouseclick_state("mouseclick:\nringSize: 18\n") is None
    assert ease_out(0) == 0 and ease_out(1) == 1
    assert 0 < ease_out(0.5) < 1
    assert clamp("120", 20, 400, 150) == 120
    assert clamp("bad", 20, 400, 150) == 150
    assert clamp("42", 5, 100, 95) == 42
    assert clamp("500", 5, 100, 95) == 100
    assert color_ok("#a1B2c3", "#ffffff") == "#a1b2c3"
    assert color_ok("bad", "#ffffff") == "#ffffff"
    assert ANIMATION_STYLES["single"][1] == 1
    assert ANIMATION_STYLES["ripple"][1] == 2
    assert ANIMATION_STYLES["waves"][1] == 4
    assert "без паутины" in ANIMATION_STYLES["single"][0]
    # Guard the shutdown regression: every modal dialog must be tracked and
    # answered before Gtk.main_quit(), or the process can retain its flock.
    assert "self.active_dialogs.append(dlg)" in inspect.getsource(App.settings_dialog)
    assert "dialog.response(Gtk.ResponseType.CANCEL)" in inspect.getsource(App.shutdown)
    print("Linux core self-tests: OK")


def gtk_init_checked():
    """
    GTK 3 bindings may return either bool or (bool, argv).
    Never treat a non-empty tuple as success: (False, []) is still truthy.
    """
    result = Gtk.init_check()
    if isinstance(result, tuple):
        return bool(result[0])
    return bool(result)


def print_diagnostics():
    print("Подсветка мыши — диагностика Linux")
    print("Python:", sys.version.split()[0])
    print("DISPLAY:", os.environ.get("DISPLAY", "(не задан)"))
    print("WAYLAND_DISPLAY:", os.environ.get("WAYLAND_DISPLAY", "(не задан)"))
    print("XDG_SESSION_TYPE:", os.environ.get("XDG_SESSION_TYPE", "(не задан)"))
    print("KDE Wayland mode:", "да (через XWayland + KWin D-Bus)" if WAYLAND_SESSION else "нет")
    print("Control socket:", str(SOCKET), "(есть)" if SOCKET.exists() else "(пока нет)")
    try:
        result = Gtk.init_check()
        ok = bool(result[0]) if isinstance(result, tuple) else bool(result)
        print("GTK init:", "OK" if ok else "ОШИБКА")
        display = Gdk.Display.get_default() if ok else None
        print("GDK display:", display.get_name() if display else "(нет)")
        if display:
            screen = Gdk.Screen.get_default()
            visual = screen.get_rgba_visual() if screen else None
            print("RGBA visual:", "OK" if visual else "НЕТ — нужен композитор окон")
        if ok and display and "wayland" not in display.get_name().lower():
            probe = xdisplay.Display()
            pointer = probe.screen().root.query_pointer()
            print("X11 pointer:", int(pointer.root_x), int(pointer.root_y))
            print("X11 shape extension:", "OK" if probe.has_extension("SHAPE") else "НЕТ")
            probe.close()
    except Exception as exc:
        print("Диагностика GTK/X11 завершилась ошибкой:", repr(exc))
        return 1
    return 0 if ok else 2


def main():
    parser = argparse.ArgumentParser(description="Подсветка мыши для Linux/X11 и KDE Wayland")
    parser.add_argument("--settings", action="store_true")
    parser.add_argument("--quit", action="store_true")
    parser.add_argument("--toggle", action="store_true")
    parser.add_argument("--diagnose", action="store_true", help="проверить окружение GTK/X11")
    parser.add_argument("--autostart", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--self-test", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--version", action="version", version=VERSION)
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    if args.diagnose:
        return print_diagnostics()

    # Send the long-supported "settings" command to existing pre-1.0.7
    # background copies as well; older instances don't understand "show".
    cmd = "quit" if args.quit else "toggle" if args.toggle else "settings" if args.settings or not args.autostart else "activate"
    if send_command(cmd, retries=10 if cmd in ("quit", "toggle", "settings") else 1):
        return 0
    if args.quit or args.toggle:
        print("Подсветка мыши сейчас не запущена или управляющий сокет недоступен:", SOCKET)
        return 2

    lock_handle = acquire_lock()
    if lock_handle is None:
        if send_command(cmd):
            return 0
        print("Подсветка мыши уже запускается. Повторите команду.", file=sys.stderr)
        return 1

    gtk_ready = False
    try:
        gtk_ready = gtk_init_checked()
        if not gtk_ready:
            raise RuntimeError(
                "GTK не смог подключиться к графическому сеансу. "
                "Проверьте DISPLAY, WAYLAND_DISPLAY и запуск из меню рабочего стола."
            )
        app = App(open_settings=args.settings)
        app.lock_handle = lock_handle
        Gtk.main()
    except Exception as exc:
        log("Ошибка запуска Linux-версии", exc)
        message = "Не удалось запустить «Подсветку мыши»:\n\n" + str(exc) + (
            "\n\nПодробности журнала: " + str(STATE / "app.log")
        )
        print(message, file=sys.stderr)
        if gtk_ready:
            try:
                dialog = Gtk.MessageDialog(
                    transient_for=None, flags=Gtk.DialogFlags.MODAL,
                    message_type=Gtk.MessageType.ERROR,
                    buttons=Gtk.ButtonsType.OK, text="Подсветка мыши",
                )
                dialog.format_secondary_text(message)
                dialog.run()
                dialog.destroy()
            except Exception as dialog_exc:
                log("Не удалось показать окно ошибки", dialog_exc)
        return 1
    finally:
        lock_handle.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
